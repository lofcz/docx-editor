from pathlib import Path
from collections import Counter
from urllib.parse import urlparse
from statistics import median
from functools import lru_cache
import json
r=Path('C:/tools/docx-perf'); app=r/'fork-long-vendor-app/combined-5a019-canonical-home-dist'
@lru_cache(10)
def lines(path): return (app/path.lstrip('/')).read_text(encoding='utf8').splitlines()
def desc(f):
 name,url,line,col=f
 if not url.startswith('http:'):return name
 path=urlparse(url).path
 s=lines(path)[line]
 # V8 columns are UTF-16 offsets.
 snippet=s.encode('utf-16-le')[(col*2):((col+110)*2)].decode('utf-16-le',errors='replace')
 return f'{name or "(anonymous)"} {path.split("/")[-1]} {line+1}:{col} {snippet}'
for op in ['undo','redo']:
 for arm in ['base']:
  totals=[]; selfs=Counter();incl=Counter()
  for f in sorted(r.glob(f'installed-history-cpu-{op}-{arm}-*.cpuprofile')):
   p=json.loads(f.read_bytes());nodes={n['id']:n for n in p['nodes']};parent={k:n['id'] for n in nodes.values() for k in n.get('children',[])}
   core=lambda n:tuple(n['callFrame'][s] for s in ['functionName','url','lineNumber','columnNumber'])
   rounds=Counter();rg=Counter()
   for i,dt in zip(p['samples'],p['timeDeltas']):
    if dt<0: continue
    chain=[];v=i
    while v:chain.append(core(nodes[v]));v=parent.get(v)
    if not any(k[0]=='az' and k[3]==182262 for k in chain):continue
    k=core(nodes[i]); rounds[k]+=dt
    seen=set()
    while i:
     k=core(nodes[i]);i=parent.get(i)
     if k in seen:continue
     seen.add(k);rg[k]+=dt
   totals.append(round(sum(rounds.values())/1000,2));selfs.update(rounds);incl.update(rg)
  if not totals:continue
  print(op,arm,len(totals),totals)
  for label,ctr in [('self',selfs),('incl',incl)]:
   for k,dt in ctr.most_common(40):print(label,round(dt/1000/len(totals),2),ascii(desc(k)))
